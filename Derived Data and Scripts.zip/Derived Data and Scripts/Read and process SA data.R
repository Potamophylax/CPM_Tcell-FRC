#install.packages("janitor")
library(tidyverse)
library(ggplot2)
library(magrittr)
library(janitor)
MSDcol <- c("#1a1866", "#f2b93b", "#b73b58", "#a2d620", "#5839bb", "#9c4ec7", "#3a6eba", "#efdd3c", "#69686d", 'grey')
sem <- function(x) sd(x)/sqrt(length(x))
#################################################################
source_path <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(source_path )
#################################################################
dt_control <- read.csv('Control.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT))

TT_mean <- mean(dt_control$TT)

dt_control <- dt_control %>% 
 # mutate(TT = 4.5 * TT  / 60) %>% 
  mutate(LSI = 4.5 * (TT - TT_mean) / (60 * 0.1) )  
mean(dt_control$LSI)
sem(dt_control$LSI)

#====================================================

dt_temp <- read.csv('T = 7.7.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT)) %>% 
  mutate(LSI = 4.5 * (TT - TT_mean) / 60 ) %>%
  mutate(LSI = LSI / 0.1) #0.7
mean(dt_temp$LSI)
sem(dt_temp$LSI)

dt_grad <- read.csv('chem = 11.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT)) %>% 
  mutate(LSI = 4.5 * (TT - TT_mean) / 60 ) %>%
  mutate(LSI = LSI / 0.1)#1
mean(dt_grad$TT)
mean(dt_grad$LSI)
sem(dt_grad$LSI)

dt_jcf <- read.csv('Jcf = 1.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT)) %>% 
  mutate(LSI = 4.5 * (TT - TT_mean) / 60 ) %>%
  mutate(LSI = LSI / 0.1) #1
mean(dt_jcf$LSI)
sem(dt_jcf$LSI)

dt_jcm <- read.csv('Jcm = 11.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT))%>% 
  mutate(LSI = 4.5 * (TT - TT_mean) / 60 ) %>%
  mutate(LSI = LSI / 0.1) #1
mean(dt_jcm$LSI)
sem(dt_jcm$LSI)

dt_teta <- read.csv('theta = 66.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT))%>% 
  mutate(LSI = 4.5 * (TT - TT_mean) / 60 ) %>%
  mutate(LSI = LSI / 0.1) #6
mean(dt_teta$LSI)
sem(dt_teta$LSI)

dt_prot <- read.csv('prot = 11.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT))%>% 
  mutate(LSI = 4.5 * (TT - TT_mean) / 60 ) %>%
  mutate(LSI = LSI / 0.1) #1
mean(dt_prot$TT)
mean(dt_prot$LSI)
sem(dt_prot$LSI)

dt_area <- read.csv('area = 11.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT))%>% 
  mutate(LSI = 4.5 * (TT - TT_mean) / 60 ) %>%
  mutate(LSI = LSI / 0.1) #1
mean(dt_area$TT)
mean(dt_area$LSI)
sem(dt_area$LSI)

dt_peri <- read.csv('peri = 2.2.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT))%>% 
  mutate(LSI = 4.5 * (TT - TT_mean) / 60 ) %>%
  mutate(LSI = LSI / 0.1) #0.2
mean(dt_peri$TT)
mean(dt_peri$LSI)
sem(dt_peri$LSI)

dt_tau <- read.csv('tau = 11.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT))%>% 
  mutate(LSI = 4.5 * (TT - TT_mean) / 60 ) %>%
  mutate(LSI = LSI / 0.1) #1
mean(dt_tau$TT)
mean(dt_tau$LSI)
sem(dt_tau$LSI)
#################################################################
# Create data for 5th hypothesis

data <- data.frame(
  name = c("T", "\u03BB_chem", "\u03BB_Pr", "\u03C4", "Jcf", "Jcm", "\U0394\u03B8", 
           "\u03BB_Ar", "\u03BB_Per", "Dummy Parametr") ,  
  LSI          = c(mean(dt_temp$LSI), mean(dt_grad$LSI), mean(dt_prot$LSI), 
                   mean(dt_tau$LSI),  mean(dt_jcf$LSI),  mean(dt_jcm$LSI), 
                   mean(dt_teta$LSI), mean(dt_area$LSI), mean(dt_peri$LSI), 
                   mean(dt_control$LSI)),
  #delta_par = c(0.7, 1, 1, 1, 1, 1, 6),
  sem = c(sem(dt_temp$LSI), sem(dt_grad$LSI), sem(dt_prot$LSI), 
          sem(dt_tau$LSI),  sem(dt_jcf$LSI),  sem(dt_jcm$LSI), 
          sem(dt_teta$LSI), sem(dt_area$LSI), sem(dt_peri$LSI), 
          sem(dt_control$LSI))
) %>% 
  mutate(UPPER = LSI + sem, LOWER = LSI - sem)

# Barplot  \U03C4  \U1D70F
p_SA <- ggplot(data, aes(x = reorder(name, LSI), y = LSI, fill=as.factor(name) )) + 
  geom_bar(stat = "identity") +
  geom_errorbar(data = data, aes(ymin = LOWER, ymax = UPPER), width = 0.2, position=position_dodge(.9), col = 'red') +
  #scale_fill_manual(values = c("#9c4ec7","#3a6eba", "#b73b58", "#5839bb", "#f2b93b", "#a2d620", "#1a1866") ) +
  scale_fill_manual(values = MSDcol) +
  labs(x = "Parameter", y = "Local Sensitivity Indices") +
  theme_bw() +
  theme(legend.position="none")
p_SA
getwd()
ggsave("CPM_SA_5.png", p_SA, width = 8, height = 4)

################################################################################
#########################  Model 4  ############################################
dt_control <- read.csv('4_Control.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT)) %>% mutate(TT = 4.5 * TT  / (200 * 60) )

TT_mean_4 <- mean(dt_control$TT)

dt_control <- dt_control %>% 
  mutate(LSI = (TT - TT_mean_4) / 0.1 )  
mean(dt_control$LSI)
sem(dt_control$LSI)

#====================================================

dt_temp <- read.csv('4_temp = 7.7.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT)) %>% mutate(TT = 4.5 * TT  / (200 * 60) ) %>% 
  mutate(LSI = (TT - TT_mean_4) / 0.1 )
mean(dt_temp$LSI)
sem(dt_temp$LSI)

dt_hapt <- read.csv('4_hapt = 11.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT)) %>% mutate(TT = 4.5 * TT  / (200 * 60) ) %>% 
  mutate(LSI = (TT - TT_mean_4) / 0.1 )
mean(dt_hapt$TT)
mean(dt_hapt$LSI)
sem(dt_hapt$LSI)

dt_jcf <- read.csv('4_Jcf = 0.1.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT)) %>% mutate(TT = 4.5 * TT  / (200 * 60) ) %>% 
  mutate(LSI = (TT - TT_mean_4) / 0.1 )
mean(dt_jcf$LSI)
sem(dt_jcf$LSI)

dt_jcm <- read.csv('4_Jcm = 1.1.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT)) %>% mutate(TT = 4.5 * TT  / (200 * 60) ) %>% 
  mutate(LSI = (TT - TT_mean_4) / 0.1 )
mean(dt_jcm$LSI)
sem(dt_jcm$LSI)

dt_area <- read.csv('4_area = 1.1.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT)) %>% mutate(TT = 4.5 * TT  / (200 * 60) ) %>% 
  mutate(LSI = (TT - TT_mean_4) / 0.1 )
mean(dt_area$TT)
mean(dt_area$LSI)
sem(dt_area$LSI)

dt_peri <- read.csv('4_peri = 1.1.csv', header = F) %>% 
  slice(7:n()) %>% 
  row_to_names(row_number = 1) %>% 
  select(TT) %>% 
  mutate(TT = as.numeric(TT)) %>% mutate(TT = 4.5 * TT  / (200 * 60) ) %>% 
  mutate(LSI = (TT - TT_mean_4) / 0.1 )
mean(dt_peri$TT)
mean(dt_peri$LSI)
sem(dt_peri$LSI)

# Create data
data <- data.frame(
  name = c("T", "\u03BB_hapt", "Jcf", "Jcm", "\u03BB_Ar", "\u03BB_Per", "Dummy Parametr") ,  
  LSI          = c(mean(dt_temp$LSI), mean(dt_hapt$LSI), mean(dt_jcf$LSI),  mean(dt_jcm$LSI), 
                   mean(dt_area$LSI), mean(dt_peri$LSI), mean(dt_control$LSI)),
  sem = c(sem(dt_temp$LSI), sem(dt_hapt$LSI), sem(dt_jcf$LSI),  sem(dt_jcm$LSI), 
          sem(dt_area$LSI), sem(dt_peri$LSI), sem(dt_control$LSI))
) %>% 
  mutate(UPPER = LSI + sem, LOWER = LSI - sem)

# Barplot
p_SA_four <- ggplot(data, aes(x = reorder(name, LSI), y = LSI, fill=as.factor(name) )) + 
  geom_bar(stat = "identity") +
  geom_errorbar(data = data, aes(ymin = LOWER, ymax = UPPER), width = 0.2, position=position_dodge(.9), col = 'red') +
  scale_fill_manual(values = c("#5839bb", "#9c4ec7", "#b73b58", "#a2d620", "#f2b93b", "#3a6eba", "#1a1866") ) +
  labs(x = "Parameter", y = "Local Sensitivity Indices") +
  theme_bw()+
  theme(legend.position="none")
p_SA_four

getwd()
 ggsave("CPM_SA_4.png", p_SA_four, width = 6, height = 4)
################################################################################
######################### Model ? 1 Statistics #################################

 TT_1 <- c(13083, 13949, 29070, 12753, 12326, 12063, 12847, 12181, 12473, 12213, 
           11599, 12790, 13601, 13225)
mean(TT_1) 
sd(TT_1)/sqrt(length(TT_1))

### Minutes
4.5 * mean(TT_1) / (200 * 60) 
4.5 * sd(TT_1)/sqrt(length(TT_1)) / (200 * 60)
